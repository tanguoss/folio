/*jslint browser: true*/
/*jslint white: true */

// Initialise Pixels

pixels.options({
	loadDelay: 100,
	resizeOpacity: 1
})

pixels.onload(function () {
	
    
    var date = new Date();
    var hours = date.getHours();
    var min = date.getMinutes()/60*100;
    var time = hours + min/100;
    
    var month = date.getMonth();
    var season = '', sunrise, sunset;
    
    switch(month) {
        case 12:
        case 1:
        case 2:
            season = 'winter';
            sunrise = 8.5;
            sunset = 19.5;
            break;
        case 3:
        case 4:
        case 5:
            season = 'spring';
            sunrise = 7.5;
            sunset = 20.5;
            break;
        case 6:
        case 7:
        case 8:
            season = 'summer';
            sunrise = 6.5;
            sunset = 21.5;
            break;
        case 9:
        case 10: 
        case 11:
            season = 'fall';
            sunrise = 7.5;
            sunset = 20.5;
            break;
    }
    
    if(time < sunrise || time > sunset) {
        console.log('dark mode on');
        addClass(document.body, 'dark-mode');
    }
    
    var $body = document.body;
    addClass(document.getElementById('loader'), 'remove');
    
    document.getElementById('toggle').addEventListener('click', function(e){
        
        if(hasClass($body, 'dark-mode')){
            console.log('obj');
            removeClass($body, 'dark-mode')
        }
        else addClass($body, 'dark-mode');
    })
    
    forEach('.pixider', function($el){
        var slider = new Pixider($el, {
            'extend': true
        });
    });
    
})
