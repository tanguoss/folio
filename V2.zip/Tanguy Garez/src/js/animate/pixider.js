var Pixider = function($dom, $options){
	var $main = $dom;

	// Gloval variables
	var $content = $main.querySelector('.pixider-content'),
		 $timestamp = null,
		 $last_mouse_x = null,
		 $velocity_x = 0,
		 $init_pos,
		 $init_click,
		 $pixider,
		 $current_slide,
		 $slider_moving = false,
		 $slider_placed,
		 $saved_options,
		 $filler;

	// Pixider defaults
	var $slider_snap = false,
		 $slider_velocity = 0.9;

	$saved_options = $options;
	if($options){

		// Set up control events
		if ($options['controls'] === true && $main.querySelector('.prev') && $main.querySelector('.next')) {
			$main.querySelector('.prev').addEventListener('click', function(){
				scrollToPrev();
			});
			$main.querySelector('.next').addEventListener('click', function(){
				scrollToNext();
			});
		}
		// Set un snap to slides
		// To do

		// Change default velocity
		// To do

		// Stretch slider to the edge of the window
		if($options['extend'] === true){extend();}
		else if(!hasClass($content, 'guttered')){
			noExtend();
		}
	}
	else{
		// To do
	}
	
	this.recalculate = function(){
		
		if($saved_options['extend'] === true){extend();}
		else if(!hasClass($content, 'guttered')){
			noExtend();
		}
	}

	// Resize the slider
	
	pixels.onresize(function(){
		if($saved_options['extend'] === true){extend();}
		else if(!hasClass($content, 'guttered')){
			noExtend();
		}
	})

	// Mouse events
	$main.addEventListener('mousedown', function (e) {

		window.removeEventListener('mouseup', mouseUp, false);
		e.preventDefault();

		$init_pos = $content.scrollLeft;
		$init_click = e.pageX;

		$content.addEventListener('mousemove', velocity, false);
		$content.addEventListener('mousemove', dragIt, false);
		window.addEventListener('mouseup', mouseUp, false);
	}, false);

	// Setup pixider size
	
	function noExtend(){
		var $last = $main.querySelector('.pixider-content >*:last-of-type');
		var $modifier = getCSS($content, 'padding-left');
		setCSS($last, {
			'margin-right': $modifier
		});
	}
	
	function extend(){
        
		setCSS($content, {
			'padding-right': '',
			'padding-left': ''
		});
		var $modifier = parseFloat(getCSS($content, 'padding-left'));
		
		setCSS($main, {
			'max-width': '',
			'width': '',
			'margin-right': '',
			'margin-left': '',
			'padding-right': '',
			'padding-left': ''
		});
        
        console.log($main);

		var $offset_left = $main.offsetLeft + $modifier;
		var $offset_right = $main.offsetLeft + $modifier;
		var $main_padding = getCSS($main, 'padding-left');

		setCSS($main, {
			'max-width': '100%',
			'width': '100%',
			'margin-right': '0px',
			'margin-left': '0px',
			'padding-right': '0px',
			'padding-left': '0px'
		});

		setCSS($main.querySelector('.pixider-content'), {
			'padding-left': parseFloat($offset_left) + parseFloat($main_padding) + 'px',
			'padding-right': parseFloat($offset_right) + parseFloat($main_padding) + 'px',
		});
		
		if($filler == null){
			$filler = document.createElement('div');
			$content.appendChild($filler);
		}
		
		setCSS($filler, {'width': ''});
		var $first = $main.querySelector('.pixider-content >*:first-of-type');
		var $calc = $first.offsetLeft - parseFloat(getCSS($first, 'margin-left')) * 2;
		setCSS($filler, {'width': $calc + 'px'});
		console.log($calc);
		
	}

	// Mouse end event
	function mouseUp(e) {
		$content.removeEventListener('mousemove', velocity, false);
		$content.removeEventListener('mousemove', dragIt, false);
		$slider_placed = false;
		replaceSlider($content);
	}

	// Scroll content with mouse
	function dragIt(e) {
		this.scrollLeft = $init_pos + ($init_click - e.pageX);
	}

	// Calculate mouse velocity
	function velocity(e) {

		var contact;
		if ($timestamp === null) {
			$timestamp = Date.now();
			if (e.pageX == undefined) {
				contact = e.touches;
				$last_mouse_x = contact[0].pageX;
			} 
			else $last_mouse_x = e.pageX;
			return;
		}

		var now = Date.now();
		var dt = now - $timestamp;
		var dx;
		if (e.pageX == undefined) {
			contact = e.touches;
			dx = contact[0].pageX - $last_mouse_x;
		} 
		else dx = e.pageX - $last_mouse_x;
		$velocity_x = Math.round(dx / dt * 10);
		$timestamp = now;

		if (e.pageX == undefined) {
			contact = e.touches;
			$last_mouse_x = contact[0].pageX;
		} 
		else $last_mouse_x = e.pageX;
	}

	// Scroll on mouse release
	function replaceSlider(el) {
		var moving = setInterval(function () {
			if($velocity_x < -1 || $velocity_x > 1) {
				el.scrollLeft = el.scrollLeft - $velocity_x;
				$velocity_x = $velocity_x * $slider_velocity;
			} 
			else{
				clearInterval(moving);
				$slider_placed = true;
				$velocity_x = 0;
				$timestamp = null;
			}
		}, 10);
	}

	// Find most central slide
	function getActiveSlide(){
		var $slide_offset = 0;
		var $found = false;
		Array.prototype.forEach.call(
			$main.querySelectorAll('.pixider-content>div'), 
			function($el, $index) {
				if($found != true){
					var $content_center = ($content.offsetWidth - parseFloat(getCSS($content, 'padding-left')) - parseFloat(getCSS($content, 'padding-right'))) / 2 + $content.scrollLeft;
					$slide_offset += outerWidth($el);

					if($content_center <= $slide_offset){
						$found = true;
						$current_slide = $el;
					}
				}
			}
		);
		return $current_slide;
	}

	var $end;
	function scrollToNext(){
		
		var $tmp = parseFloat(getCSS($content, 'padding-right')) + parseFloat(getCSS($content, 'margin-right'));
		var $end = getTotalWidth() - window.innerWidth + $tmp * 2;
		
		if($end >= $content.scrollLeft){
			var $next = getActiveSlide().nextElementSibling;
			var $calc = $next.offsetLeft + $next.offsetWidth / 2 - window.innerWidth / 2 - parseFloat(getCSS($next, 'margin-left'));
			if($next && $calc < $end){
				scrollToPosition($calc);
			}
			else scrollToPosition($end);
			
		}
	}

	function scrollToCurrent(){
		var $calc = $current_slide.offsetLeft + $current_slide.offsetWidth / 2 - window.innerWidth / 2 - parseFloat(getCSS($current_slide, 'margin-left'));
		scrollToPosition($calc);
	}

	function scrollToPrev(){
		if(getActiveSlide().previousElementSibling){
			var $prev = getActiveSlide().previousElementSibling;
			if($content.scrollLeft === $end){
				var $slides = $main.querySelectorAll('.pixider-content>div');
				$prev = $slides[$slides.length - 2];
			}
			var $calc = $prev.offsetLeft + $prev.offsetWidth / 2 - window.innerWidth / 2 - parseFloat(getCSS($prev, 'margin-left'));

			if($calc < 0) scrollToPosition(0);
			else {
				scrollToPosition($calc);
			}
		}
		else{
			if($content.scrollLeft !== 0){
				scrollToPosition(0);
			}
		}
	}

	function getTotalWidth(){
		var $calc = 0;
		Array.prototype.forEach.call(
			$main.querySelectorAll('.pixider-content>div'), 
			function($el, $index) {
				$calc += outerWidth($el);
			}
		);
		return $calc;
	}

	function scrollToPosition($pos){

		var $fps = 60;
		var $from = $content.scrollLeft;
		var $to = $pos;
		var $duration = 1000; // 500ms
		var $start = new Date().getTime();

		function easeInOutQuart(t, b, c, d) {
			if ((t /= d / 2) < 1) return c / 2 * t * t * t * t + b;
			return -c / 2 * ((t -= 2) * t * t * t - 2) + b;
		}
		if(!$slider_moving){
			$slider_moving = true;
			var $timer = setInterval(function() {
				var $time = new Date().getTime() - $start;
				var $x = easeInOutQuart($time, $from, $to - $from, $duration);
				$content.scrollLeft = $x;
				if ($time >= $duration){
					$slider_moving = false;
					clearInterval($timer);
				}
			}, 1000 / $fps);
		}

	}
}