function parallax($dom){
	
	if($dom !== undefined){
		if($dom.hasAttribute('data-parallax')){
			placeBkg($dom);
		}
	}
	
	else{
		Array.prototype.forEach.call(
			document.querySelectorAll('[data-parallax]'), 
			function($el, $index) {
				if(hasClass($el, 'background')){
					placeBkg($el);
					pixels.onresize(function(){placeBkg($el)});
				}
				scrollParallax($el);
				pixels.onscroll(function(){scrollParallax($el)})
			}
		);
	}
	
	function scrollParallax($el){
		
		var isInview = false;
		if(hasClass($el, 'background')){
			isInview = isInViewport($el.parentElement);
		}
		else isInview = isInViewport($el);

		if(isInview){

			var amount = parseFloat($el.getAttribute('data-parallax')) / 100;
			var offsetTop;
			if(hasClass($el, 'background')){
				offsetTop = $el.parentElement.getBoundingClientRect().top + window.pageYOffset + parseFloat($el.style.marginTop);
			}
			else {
				offsetTop = $el.getBoundingClientRect().top + window.pageYOffset + parseFloat(getCSS($el, 'margin-top'));
			}
			var windowHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0) / 2;

			var calc = window.pageYOffset * amount - ((offsetTop - (windowHeight - $el.offsetHeight/2)) * amount);
			//console.log(getCSS($el, 'transform'));
			setCSS($el, {'transform': 'translate3d(0, '+-calc+'px, 0)'});
		}
	}
	
	function placeBkg($el){
		
		setCSS($el.parentElement, {'overflow': 'hidden'});

		// Reset defaults
		setCSS($el, {
			'height': '',
			'margin-top': ''
		});
		var $amount = parseFloat($el.getAttribute('data-parallax') / 100),
			 $added,
			 $margin,
			 $calc;

		if($amount < 0){
			$added = -$amount + 1;
			var tmp;

			if($el.parentElement.offsetHeight <= window.innerHeight){
				$calc = $el.parentElement.offsetHeight + window.innerHeight * -$amount;
				$el.style.height = $calc + 'px';
			}
			else{
				$amount = -$amount;
				tmp = $el.parentElement.offsetHeight - window.innerHeight;
				$calc = $el.parentElement.offsetHeight;
				$el.style.height = $calc + 'px';
			}

			$margin = -($el.offsetHeight - $el.parentElement.offsetHeight) / 2;
			$el.style.marginTop = $margin + 'px';
		}
		else{
			$el.style.height = $el.parentElement.offsetHeight + window.innerHeight * ($amount * 2) + 'px';
			$margin = -($el.offsetHeight - $el.parentElement.offsetHeight) / 2;
			$el.style.marginTop = $margin + 'px';
		}
	}
}