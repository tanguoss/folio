// Pixels functions

function waitForImages($el, $callback){
	if($el.querySelectorAll('img[src]:not([src*="svg"])')){
		var $count = $el.querySelectorAll('img[src]:not([src*="svg"])').length;
		if($count == 0 && $callback && typeof($callback) === "function") {
			$callback();
		}
		else{
			Array.prototype.forEach.call(
				$el.querySelectorAll('img'), 
				function($img, $index) {
					var $int = $index + 1;
					if($img.complete){
						addLoaded($int);
					}
					else{
						$img.addEventListener('load', function () {
							addLoaded($int);
						});
					}
				}
			);
		}
		function addLoaded($int){
			if($int == $count){
				if ($callback && typeof($callback) === "function") {
					$callback();
				}
			}
		}
	}
	else{
		if($callback && typeof($callback) === "function") {
			$callback();
		}
	}
}

function textAdapt(el){

	var tmp = window.getComputedStyle(el, null)['line-height'];
	el.style.height = tmp;
	var calc = el.scrollHeight;
	var mod = -3;
	if(hasClass(el, 'outlined') || hasClass(el, 'underlined')){
		mod = parseFloat(window.getComputedStyle(el, null)['border-width']) * 2;
	}
	calc = calc + mod;
	el.style.height = calc + 'px';
}

/* Convert SVG icons to inline SVG*/

function svgInline() {

	var els = document.querySelectorAll('img.inline-svg[src$=".svg"]');
	Array.prototype.forEach.call(els, function (el, index) {
		
		var imgURL = el.getAttribute('src'),
			 id = el.getAttribute('id'),
			 cla = el.getAttribute('class'),
			 svg,
			 httpRequest = new XMLHttpRequest();

		httpRequest.onreadystatechange = function (data) {
			var parser = new DOMParser();
			var target;
			if (data.target.response !== null) {
				target = data.target.response;
			} else target = data.srcElement.response;
			svg = parser.parseFromString(target, "text/xml").querySelector('svg');

			if (svg !== null && el.parentNode !== null) {
				svg.setAttribute('id', id);
				svg.setAttribute('class', cla);
				el.parentNode.insertBefore(svg, el);
				el.parentNode.removeChild(el);
			}
		};
		httpRequest.open('GET', imgURL);
		httpRequest.send();
	});
}


function showOverlay(){
	if(pixels.overlay == null){
		var $overlay = document.createElement('div');
		addClass($overlay, 'overlay');
		document.documentElement.append($overlay);
		setTimeout(function() {
			setCSS($overlay, {'opacity': 1});
		}, 0);
		pixels.overlay = $overlay;
	}
}

function hideOverlay(){
	if(pixels.overlay != null){
		var $overlay = pixels.overlay;
		setCSS($overlay, {
			'opacity': 0
		});
		setTimeout(function() {
			remove($overlay);
		}, getTransitionDuration($overlay));
		pixels.overlay = null;
	}
}


forEach('[data-include]', function($el){
	var $file = $el.getAttribute('data-include');
	$el.innerHTML = includeFile($el, $file);
})

function includeFile($dom, $file, callback){
	if(isElement($dom)) include($dom);
	else include(document.querySelector($dom));
	
	function include($el){
		var $xhr= new XMLHttpRequest();
		$xhr.open('GET', $file, true);
		var $xhr= new XMLHttpRequest();
		$xhr.open('GET', $file, true);
		$xhr.onreadystatechange= function() {
			if (this.readyState!==4) return;
			if (this.status!==200) return; // or whatever error handling you want
			$el.innerHTML= this.responseText;
			
			forEach($el.querySelectorAll('[data-include]'), function($new){
				var $file = $new.getAttribute('data-include');
				$new.innerHTML = includeFile($new, $file);
			})
			
			if(callback && typeof (callback) === "function") {
				callback();
			}
		};
		$xhr.send();
	}
}

function documentOffset($el){
	return {
		'top': $el.getBoundingClientRect().top + document.documentElement.scrollTop - parseFloat(getCSS($el, 'margin-top'))
	};
}

function documentScroll(){
	return Math.max(window.pageYOffset, document.documentElement.scrollTop, document.body.scrollTop);
}