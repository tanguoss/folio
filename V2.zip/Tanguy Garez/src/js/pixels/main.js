/*jslint browser: true*/
/*jslint white: true */
/*global $, jQuery, alert, pixelsInit, toast, console*/

var animatables = [];

var Pixels = function () {

	var $loaded, $resized, $resizing, $scrolled;
	var $tmp_window_width;
	var $this = this;
	this.settings = {
		'loadDelay': 0,
		'scrollUpdate': 15,
		'resizeDebounce': 500,
		'resizeOpacity': 1,
		'textAnimationSpeed': 1,
		'revealOffset': 20, // Percentage of screen height
	};

	// Set custom settings
	this.options = function ($options) {
		for (var $key in $this.settings) {
			if ($options[$key]) this.settings[$key] = $options[$key];
		}
	};

	this.setup = function () {
		waitForImages(document.documentElement, function () {
			// wait for possible settings
			setTimeout(function () {
				
				if(isFunction(svgInline)) svgInline();
				
				setupAnimations();
				textAnimations();
				extend();
				parallax();
				
				if($loaded) document.dispatchEvent($loaded);
			}, $this.settings.loadDelay);
		})
	};

	// Custom events
	this.onload = function (callback) {
		$loaded = new createNewEvent('pixelsLoad');
		document.addEventListener('pixelsLoad', function () {
			if (callback && typeof (callback) === "function") {
				callback();
			}
		});
	};
	this.onresize = function (callback) {
		$resized = new createNewEvent('pixelsResize');
		document.addEventListener('pixelsResize', function () {
			if (callback && typeof (callback) === "function") {
				callback();
			}
		});
	};
	this.onscroll = function (callback) {
		$scrolled = new createNewEvent('pixelsScroll');
		document.addEventListener('pixelsScroll', function () {
			if (callback && typeof (callback) === "function") {
				callback();
			}
		});
	};

	// Pixels events
	window.addEventListener('scroll', throttle(function (e) {
		if ($scrolled) document.dispatchEvent($scrolled);
	}, this.settings.scrollUpdate));

	// Resize start
	window.addEventListener('resize', function () {
		if ($resizing !== true) {
			if(window.innerWidth < 800) $tmp_window_width = window.innerWidth;
			$resizing = true;
			setCSS(document.body, {
				'opacity': $this.settings.resizeOpacity
			});
		}
	});
	
	// Resize end
	window.addEventListener('resize', debounce(function () {
		$resizing = false;
		setCSS(document.body, {
			'opacity': 1
		});
		if(window.innerWidth > 800 || window.innerWidth != $tmp_window_width){
			if ($resized) document.dispatchEvent($resized);
		}
		
	}, $this.settings.resizeDebounce));

};

var pixels = new Pixels();

window.addEventListener('load', function () {
	//pixels = new Pixels();
	waitForImages(document.querySelector('body'), function () {
		pixels.setup();
	});
});