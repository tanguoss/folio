
function textAnimations(){
    Array.prototype.forEach.call(document.querySelectorAll('*[data-letter-anim]'), function ($el, $index) {
		var $anim = letters($el);
		animateTextIfInView($el, $anim, 10);
	});
	
	Array.prototype.forEach.call(document.querySelectorAll('*[data-word-anim]'), function ($el, $index) {
		var $anim = words($el);
		animateTextIfInView($el, $anim, 30);
	});
	
	Array.prototype.forEach.call(document.querySelectorAll('*[data-line-anim]'), function ($el, $index) {
		var $anim = lines($el);
		animateTextIfInView($el, $anim, 120);
	});
	
	function animateTextIfInView($el, $anim, $speed){
		if (isInViewport($el) && !hasClass($el, 'animated')) $anim.animate($speed);
		else {
			pixels.onscroll(function () {
				if (!hasClass($el, 'animated') && isInViewport($el)) $anim.animate($speed);
			})
		}
	}
}

function letters($dom) {
	var tmp = new Text($dom, /(\s+)/);
	Array.prototype.forEach.call(
		$dom.querySelectorAll('span'), 
		function($el, $index) {
			if ($el.innerHTML != ' ') setCSS($el, {
				'display': 'inline-block'
			})
			addClass($el, 'no-wrap');
			var letter = new Text($el, '');
		}
	);
	return tmp;
}

function words($dom) {
	var tmp = new Text($dom, /(\s+)/);
	return tmp;
}

function lines($dom) {
	var tmp = new Text($dom, /(\s+)/);
	tmp.setLines();
	return tmp;
}

var Text = function ($dom, $split) {
	
	// Check to see if animation already attached
	
	var exists = animatables.filter(function(el){ return el.dom === $dom })[0];
	if(exists) return exists;

	
	var $this = this, animated = false, is_setup = false;
	this.settings = {
		interval: 10
	}
	addSpans();

	function addSpans() {
		var $string = $dom.textContent;
		$string = $string.split($split);
		var $i = 0;
		var $length = $string.length;
		$dom.innerHTML = '';
		for ($i; $i < $length; $i++) {
			$dom.innerHTML += "<span>" + $string[$i] + "</span>";
		}
	}

	this.setLines = function () {
		var $offset = 0;
		var $lines = [];
		var $output = '';

		Array.prototype.forEach.call(
			$dom.querySelectorAll('span'),
			function ($span, $index) {
				
				if ($span.getBoundingClientRect().top == $offset || $offset == 0) {
					$output += $span.innerHTML;
					$offset = $span.getBoundingClientRect().top;
				} else {
					$lines.push($output);
					$offset = $span.getBoundingClientRect().top;
					$output = $span.innerHTML;
				}
				if ($index == $dom.querySelectorAll('span').length - 1) {
					$lines.push($output);
				}

			}
		);

		$dom.innerHTML = '';
		$lines.forEach(function ($line, $index) {
			var $span = document.createElement('span');
			$span.innerHTML = $line + ' ';
			$dom.appendChild($span);
		});
	}
	
	function setup(){
		Array.prototype.forEach.call(
			$dom.querySelectorAll('span:not(.no-wrap)'),
			function ($el, $index) {
				if ($el.innerHTML != ' ') setCSS($el, {
					'display': 'inline-block'
				})
				if ($dom.hasAttribute('data-letter-anim'))$el.setAttribute('data-load-anim', $dom.getAttribute('data-letter-anim'));
				else if ($dom.hasAttribute('data-word-anim')) $el.setAttribute('data-load-anim', $dom.getAttribute('data-word-anim'));
				else if ($dom.hasAttribute('data-line-anim')) $el.setAttribute('data-load-anim', $dom.getAttribute('data-line-anim'));
				else if ($dom.hasAttribute('data-anim-length')) $el.setAttribute('data-anim-length', $dom.getAttribute('data-anim-length'));

				if ($this.settings.interval == 'random'){
					setCSS($el, {
						'animation-delay': Math.floor(Math.random() * 500)+'ms',
						'opacity': ''
					});
				}
				else setCSS($el, {
					'animation-delay': $index * $this.settings.interval + 'ms',
					'opacity': ''
				});
			}
		)
		is_setup = true;
	}

	this.animate = function () {
		if(!animated){
			animated = true;
			addClass($dom, 'animated');
			if(!is_setup) setup();
		}
	}
	
	this.reset = function(){
		if(animated){
			animated = false;
			removeClass($dom, 'animated');
		}
	}
}