var Moveable = function ($el) {

	// Set defaults
	var $this = this;
	this.dom = $el;
	this.extracted = false;
	this.currentOffsetTop = 0;
	this.currentOffsetLeft = 0;
	var $default = {
		'width': $el.offsetWidth,
		'height': $el.offsetHeight,
		'parentNode': $el.parentNode
	}

	// Add onresize to reset defaults

	// Extract node to body
	this.extract = function () {
		$placeholder = document.createElement('div');
		copyAttributes($el, $placeholder);
		setCSS($placeholder, {
			'height': $el.offsetHeight + 'px',
			'visibility': 'hidden'
		})
		setCSS($el, {
			'width': $el.offsetWidth + 'px',
			'height': $el.offsetHeight + 'px',
			'position': 'absolute',
			'top': $el.getBoundingClientRect().top + document.documentElement.scrollTop + 'px',
			'left': $el.getBoundingClientRect().left + document.documentElement.scrollLeft + 'px'
		})
        $el.removeAttribute('data-load-anim');
        $el.removeAttribute('data-reveal-anim');
		$el.parentNode.insertBefore($placeholder, $el);
		document.body.appendChild($el);

		this.placeholder = $placeholder;
	}

	// Move
	this.move = function ($options, $callback) {
		if (this.extracted == false) {
			this.extract();
			this.extracted = true;
		}
		var $pos = this.dom.getBoundingClientRect();
		addClass($el, 'moveable');

		// Default values
		var $left, $top;
		var $width = $options['width'] ? $options['width'] : $el.offsetWidth;
		var $height = $options['height'] ? $options['height'] : $el.offsetHeight;
		var $max_width = $options['max-width'] ? $options['max-width'] : null;
		var $max_height = $options['max-height'] ? $options['max-height'] : null;
		var $index = $options['z-index'] ? $options['z-index'] : 100;
		
        
        
		// Define position
		if ($options.top !== undefined) $top = -$pos.top + parseFloat($options.top);
		else $top = 0;
		
		if ($options.left !== undefined) $left = -$pos.left + parseFloat($options.left);
		else $left = 0;
		
		setTimeout(function () {
			var $translate = ' translate3d(' + $left + 'px, ' + $top + 'px, 0)';
			setCSS($this.dom, {
				'transform': $translate,
				'z-index': $index,
				'width': $width,
				'height': $height
			});
		}, 10)
		setTimeout(function () {
			removeClass($this.dom, 'moveable');
		}, getTransitionDuration($this.dom));
	}

	// Reset to initial position
	this.reset = function ($callback) {
		setCSS(this.dom, {
			'transform': '',
			'width': $default.width + 'px',
			'height': $default.height + 'px'
		});
		var $this = this;
		setTimeout(function () {
			$this.remove();
		}, getTransitionDuration($this.dom));
	}
	
	pixels.onresize(function(){
		$this.remove();
	})

	// Reset DOM and delete placeholder
	this.remove = function () {
		if(this.extracted == true){
			this.extracted = false;
			setCSS(this.dom, {
				'transform': '',
				'position': '',
				'z-index': '',
				'width': '',
				'height': '',
				'top': '',
				'left': ''
			});

			$default.parentNode.insertBefore(this.dom, this.placeholder);
			$default.parentNode.removeChild(this.placeholder);
		}
	}
}