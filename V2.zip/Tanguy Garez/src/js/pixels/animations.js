
function setupAnimations(){
	var $offset = (window.innerHeight * pixels.settings.revealOffset) / 100; // recalc on resize
	
	forEach('[data-reveal-anim]', function($el){
		var anim = new Animatable($el, {'cascade': true});

		if (isInViewport($el, $offset)) anim.play();
		pixels.onscroll(function(){
			if (isInViewport($el, $offset)) anim.play();
			if($el.getBoundingClientRect().top - window.innerHeight > 0) anim.reset();
		})
	});
	
	Array.prototype.forEach.call(
		document.querySelectorAll('[data-load-anim]'), 
		function($el, $index) {
			if(!isElement(getClosest($el, '[data-reveal-anim]')) || !isElement(getClosest($el, '[data-load-anim]'))){
				var anim = new Animatable($el);
				anim.play();
			}
		}
	);
}

function loadAnimations($dom){
	Array.prototype.forEach.call(
		$dom.querySelectorAll('[data-load-anim]'), 
		function($el, $index) {
			var anim = new Animatable($el);
			anim.play();
		}
	);
}

function resetAnimations($dom){
	Array.prototype.forEach.call(
		$dom.querySelectorAll('[data-load-anim], [data-reveal-anim]'), 
		function($el, $index) {
			var anim = new Animatable($el);
			anim.reset();
		}
	);
}


function Animatable($dom, options){
	
	// Check to see if animation already attached
	
	var exists = animatables.filter(function(el){ return el.dom === $dom })[0];
	if(exists) return exists;
	
	this.dom = $dom;
	var $this = this;
	var loaded = hasClass($dom, 'loaded');
	var delay;
	
	this.settings = {
		'cascade': false,
	}
	
	// Set custom settings
	if(options){
		for (var key in $this.settings) {
			if (options[key]) $this.settings[key] = options[key];
		}
	}
		
	if ($dom.getAttribute('data-anim-delay') !== null) {
		var delay = parseFloat($dom.getAttribute('data-anim-delay'));
	}
	else delay = 0;

	this.play = function(){
		if(!loaded){
			setCSS($dom, {
				'animation-delay': delay+'ms',
				'opacity': ''
			});
			addClass($dom, 'loaded');
			if($this.settings.cascade)setTimeout(function() {
				 loadAnimations($dom);
			}, delay);
			loaded = true;
		}
	}
	
	this.reset = function(){
		if(loaded){
			setCSS($dom, {
				'animation-delay': '',
				'opacity': ''
			});
			removeClass($dom, 'loaded');
			if($this.settings.cascade) resetAnimations($dom);
			loaded = false;
		}
	}

	this.playreverse = function(){
		if(loaded){
			var anim_time = toDuration(getCSS($dom, 'animation-duration'));
			
			setCSS($dom, {
				'opacity': getCSS($dom, 'opacity'),
				'animation-direction': 'alternate-reverse'
			});

			removeClass($dom, 'loaded');
			setTimeout(function () {
				addClass($dom, 'loaded');
				setCSS($dom, {
					'animation-direction': 'alternate-reverse'
				});
			}, 0);
			
			setTimeout(function () {
				setCSS($dom, {
					'opacity': '',
					'animation-direction': '',
				});
				removeClass($dom, 'loaded');
			}, anim_time + delay);
			loaded = false;
		}
	}
	animatables.push(this);
}
