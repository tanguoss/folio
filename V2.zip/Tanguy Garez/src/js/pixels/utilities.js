// Global functions

function parseHTML(html) {
    var t = document.createElement('template');
        t.innerHTML = html;
    return t.content.cloneNode(true);
}

function remove($dom){
	$dom.parentNode.removeChild($dom);
}

function forEach($selector, $function){
	
	if(!($selector instanceof NodeList)){
		$selector = document.querySelectorAll($selector);
	}
	Array.prototype.forEach.call(
		$selector, $function
	);
}

function createNewEvent(eventName) {
	if (typeof (Event) === 'function') {
		var event = new Event(eventName);
	} else {
		var event = document.createEvent('Event');
		event.initEvent(eventName, true, true);
	}
	return event;
}

function throttle(func, wait, options) {
	var context, args, result;
	var timeout = null;
	var previous = 0;
	if (!options) options = {};
	var later = function() {
		previous = options.leading === false ? 0 : Date.now();
		timeout = null;
		result = func.apply(context, args);
		if (!timeout) context = args = null;
	};
	return function() {
		var now = Date.now();
		if (!previous && options.leading === false) previous = now;
		var remaining = wait - (now - previous);
		context = this; 
		args = arguments;
		if (remaining <= 0 || remaining > wait) {
			if (timeout) {
				clearTimeout(timeout);
				timeout = null;
			}
			previous = now;
			result = func.apply(context, args);
			if (!timeout) context = args = null;
		} else if (!timeout && options.trailing !== false) {
			timeout = setTimeout(later, remaining);
		}
		return result;
	};
}

function debounce(callback, limit, immediate) {
	var timeout;
	return function () {
		var context = this, 
			 args = arguments;
		var later = function () {
			timeout = null;
			if (!immediate) callback.apply(context, args);
		};
		var callNow = immediate && !timeout;
		clearTimeout(timeout);
		timeout = setTimeout(later, limit);
		if (callNow) callback.apply(context, args);
	};
}

Array.prototype.contains = function(obj) {
	var i = this.length;
	while (i--) {
		if (this[i] === obj) {
			return true;
		}
	}
	return false;
};

function hasVerticalScroll(node){
	if(node == undefined){
		if(window.innerHeight){
			return document.body.offsetHeight> window.innerHeight;
		}
		else {
			return  document.documentElement.scrollHeight > 
				document.documentElement.offsetHeight ||
				document.body.scrollHeight>document.body.offsetHeight;
		}
	}
	else {
		return node.scrollHeight> node.offsetHeight;
	}
}

function hasClass (el, className) {
	if(isElement(el)){
		var reg = new RegExp(className, 'g');
		return el.className.match(reg) !== null;
	}
}

function addClass (elem, className) {   
	if (!hasClass(elem, className)) {
		elem.className += ' ' + className;
	}
}

var removeClass = function (elem, className) {
	var newClass = ' ' + elem.className.replace(/[\t\r\n]/g, ' ') + ' ';
	if (hasClass(elem, className)) {
		while (newClass.indexOf(' ' + className + ' ') >= 0) {
			newClass = newClass.replace(' ' + className + ' ', ' ');
		}
		elem.className = newClass.replace(/^\s+|\s+$/g, '');
	}
};

function prefixEvent(element, type, callback) {
	var prefixes = [
		'webkit',
		'ms',
		'moz',
		'o',
		''
	];
	for (var p = 0; p < prefixes.length; p++) {
		if (!prefixes[p]) type = type.toLowerCase();
		element.addEventListener(prefixes[p]+type, callback, false);
	}
}

function getTransitionDuration($dom) {
	var duration = window.getComputedStyle($dom, null)['transition-duration'];
	return toDuration(duration);
}

function toDuration(time){
	if(time.indexOf(',')>-1){time = time.split(','); time = time[0];}
	return (time.indexOf("ms")>-1) ? time.replace(/[a-zA-Z]+/g, '') : time.replace(/[a-zA-Z]+/g, '') * 1000;
}

function outerHeight(el){
	return el.offsetHeight + parseFloat(window.getComputedStyle(el, null)['margin-top']) + parseFloat(window.getComputedStyle(el, null)['margin-bottom']);
}

function outerWidth(el){
	return el.offsetWidth + parseFloat(window.getComputedStyle(el, null)['margin-left']) + parseFloat(window.getComputedStyle(el, null)['margin-right']);
}

function getPrefix() {
	var styles = window.getComputedStyle(document.documentElement, ''),
		pre = (Array.prototype.slice
			.call(styles)
			.join('')
			.match(/-(moz|webkit|ms)-/) || (styles.OLink === '' && ['', 'o'])
		)[1],
		dom = ('WebKit|Moz|MS|O').match(new RegExp('(' + pre + ')', 'i'))[1];
	return {
		dom: dom,
		lowercase: pre,
		css: '-' + pre + '-',
		js: pre[0].toUpperCase() + pre.substr(1)
	};
}

var $proporties_to_prefix = [
	'transform',
	'appearance',
	'filter',
	'animation'
];

function getCSS($el, $prop){
	return window.getComputedStyle($el, null)[$prop];
}

function setCSS($el, $props, $callback) {
	for (var $property in $props) {
		$el.style[$property] = $props[$property];
		if ($proporties_to_prefix.indexOf($property) > -1) {
			$el.style[getPrefix().css + $property] = $props[$property];
		}
	}
	if ($callback && typeof ($callback) === "function") {
		setTimeout(function () {
			$callback();
		}, getTransitionDuration($el));
	}
}

function copyAttributes($ori, $new) {
	for (var $i = 0; $i < $ori.attributes.length; $i++) {
		var $attr = $ori.attributes.item($i);
		$new.setAttribute($attr.nodeName, $attr.nodeValue);
	}
}

function isElement($el) {
	return $el instanceof Element;  
}

function isFunction($el){
	return typeof ($el) === "function";
}

var getClosest = function (elem, selector) {

	// Element.matches() polyfill

	if (!Element.prototype.matches) {
		Element.prototype.matches =
			Element.prototype.matchesSelector ||
			Element.prototype.mozMatchesSelector ||
			Element.prototype.msMatchesSelector ||
			Element.prototype.oMatchesSelector ||
			Element.prototype.webkitMatchesSelector ||
			function (s) {
			var matches = (this.document || this.ownerDocument).querySelectorAll(s),
				 i = matches.length;
			while (--i >= 0 && matches.item(i) !== this) {}
			return i > -1;
		};
	}

	// Get closest match

	for (; elem && elem !== document; elem = elem.parentNode) {
		if (elem.matches(selector)) return elem;
	}
	return null;
};

function isInViewport(el, added) {
	if (added == null) added = 0;
	return el.getBoundingClientRect().top - window.innerHeight + added < 0 && el.getBoundingClientRect().bottom > 0;
}