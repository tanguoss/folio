function extend(){
	
	
	Array.prototype.forEach.call(
		document.querySelectorAll('.extend-to-l'), 
		function($el, $index) {
			$el.style.left = '0px';
			$el.style.left = -$el.getBoundingClientRect().left+'px';
			pixels.onresize(function(){
				$el.style.left = '0px';
				$el.style.left = -$el.getBoundingClientRect().left+'px';
			})
		}
	);
	
	Array.prototype.forEach.call(
		document.querySelectorAll('.extend-to-r'), 
		function($el, $index) {
			$el.style.right = '';
			$el.style.width = '';
			var $calc = $el.getBoundingClientRect().right - document.documentElement.clientWidth;
			$el.style.right = $calc + 'px';
			console.log('in');
			$el.style.width = 'calc(100% + ' + -$calc + 'px)';

			pixels.onresize(function(){
				$el.style.right = '';
				$el.style.width = '';
				var $calc = $el.getBoundingClientRect().right - document.documentElement.clientWidth;
				$el.style.right = $calc + 'px';
				console.log('in');
				$el.style.width = 'calc(100% + ' + -$calc + 'px)';
			})
		}
	);
}